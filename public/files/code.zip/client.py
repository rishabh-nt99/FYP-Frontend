from collections import OrderedDict
import warnings

import flwr as fl
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset

import pandas as pd
from torch.utils.data import TensorDataset

warnings.filterwarnings("ignore", category=UserWarning)
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

#Model Parameters
input_size = 4098     # The input size should fit our fingerprint size
hidden_size = 512   # The size of the hidden layer
dropout_rate = 0.9    # The dropout rate
output_size = 1 
lr = 0.001  # The learning rate for the optimizer

#FL Parameters
client_id = 0
size = 1368500
total_clients = 2
clients = 50 #15
client_size = size / total_clients
local_batches = 256
torch_seed = 0 
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")



def train(net, trainloader, epochs):
    """Train the network on the training set."""
    criterion = nn.MSELoss()
    optimizer = torch.optim.SGD(net.parameters(), lr=0.001)
    print("Training")
    net.train()
    for _ in range(epochs):
        for images, labels in trainloader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(net(images), labels)
            loss.backward()
            optimizer.step()


def test(net, testloader):
    """Validate the network on the entire test set."""
    criterion = nn.MSELoss(reduction='sum')
    net.eval()
    loss = 0.0
    print("Testing")
    with torch.no_grad():
        for images, labels in testloader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            outputs = net(images)
            loss += criterion(outputs, labels).item()
            
    loss /= len(testloader.dataset)

    print(f"Client {client_id+1} Loss: {loss}")
    return loss


# Load your dataset in this function
def load_data():
    
    print("Loading Data")
    #  Sample code for how dataloaders should be returned
    x_train, x_test, y_train, y_test = [],[],[],[] # loadData()  

    testset = TensorDataset(x_test, y_test)
    testloader = torch.utils.data.DataLoader(dataset=testset,
                                              batch_size=local_batches,
                                              shuffle=True)
    
    trainset = TensorDataset(x_train, y_train)
    trainloader = torch.utils.data.DataLoader(dataset=trainset,
                                              batch_size=local_batches,
                                              shuffle=True)

    num_examples = {"trainset": len(trainset), "testset": len(testset)}
    print("Data Loaded!")
    return trainloader, testloader, num_examples

#Model
class Net(nn.Module):
    def __init__(self, input_size, hidden_size, dropout_rate, out_size):
        super(Net, self).__init__()
        # Twp layers and a output layer
        self.fc1 = nn.Linear(input_size, hidden_size)  # 1st Full-Connected Layer
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc_out = nn.Linear(hidden_size, out_size) # Output layer
       
        #Layer normalization for faster training
        self.ln1 = nn.LayerNorm(hidden_size)
        self.ln2 = nn.LayerNorm(hidden_size)   
        
        #LeakyReLU will be used as the activation function
        self.activation = nn.LeakyReLU()
        
        #Dropout for regularization
        self.dropout = nn.Dropout(dropout_rate)
     
    def forward(self, x):# Forward pass: stacking each layer together
        # Fully connected =&amp;gt; Layer Norm =&amp;gt; LeakyReLU =&amp;gt; Dropout times 3
        out = self.fc1(x)
        out = self.ln1(out)
        out = self.activation(out)
        out = self.dropout(out)
        out = self.fc2(out)
        out = self.ln2(out)
        out = self.activation(out)
        out = self.dropout(out)
        
        #Final output layer
        out = self.fc_out(out)
        return out

def main():
    """Create model, load data, define Flower client, start Flower client."""

    print("In Main!")
    # Load model
    torch.manual_seed(torch_seed)
    net = Net(input_size, hidden_size, dropout_rate, output_size).to(device)
    torch.cuda.empty_cache()

    # Load data (CIFAR-10)
    trainloader, testloader, num_examples = load_data()

    # Flower client
    class FedClient(fl.client.NumPyClient):
        def get_parameters(self):
            return [val.cpu().numpy() for _, val in net.state_dict().items()]

        def set_parameters(self, parameters):
            params_dict = zip(net.state_dict().keys(), parameters)
            state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
            net.load_state_dict(state_dict, strict=True)

        def fit(self, parameters, config):
            self.set_parameters(parameters)
            train(net, trainloader, epochs=1)
            return self.get_parameters(), num_examples["trainset"], {}

        def evaluate(self, parameters, config):
            self.set_parameters(parameters)
            loss = test(net, testloader)
            return float(loss), len(testloader.dataset), {"accuracy": 1}

    # Start client
    fl.client.start_numpy_client("localhost:5040", client=FedClient())


if __name__ == "__main__":
    main()